// home controller
demoApp.controller('HomeController', function ($scope) {
    $scope.header = "Welcome to home monitor";
});
demoApp.controller('TimestampController', function ($scope) {
    $scope.header = "table";
});

demoApp.controller('InfoController', function ($scope) {
    $scope.header = "description";
});
demoApp.controller('WindowController', function ($scope) {
    $scope.header = "window";
});
demoApp.controller('DoorController', function ($scope) {
    $scope.header = "door";
});
// post controller


